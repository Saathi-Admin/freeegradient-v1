FreeeGradients

Free for personal and commercial use. Attribution appreciated, not required.

Keep the gradients folder intact. Link gradients/freeegradients.css from your HTML.
Use class="fg-gradient fg-aurora-01". Change the stable variation ID to change the background.
Grain and wave templates load their adjacent SVG assets; all other templates use native CSS.
PNG/JPEG exports are available from the website.
